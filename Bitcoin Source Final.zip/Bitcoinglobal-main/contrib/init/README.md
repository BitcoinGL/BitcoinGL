Sample configuration files for:

SystemD: bitcoinglobald.service
Upstart: bitcoinglobald.conf
OpenRC:  bitcoinglobald.openrc
         bitcoinglobald.openrcconf
CentOS:  bitcoinglobald.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
