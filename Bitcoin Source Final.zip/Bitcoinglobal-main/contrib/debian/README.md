
Debian
====================
This directory contains files used to package bitcoinglobald/bitcoinglobal-qt
for Debian-based Linux systems. If you compile bitcoinglobald/bitcoinglobal-qt yourself, there are some useful files here.

## bitcoinglobal: URI support ##


bitcoinglobal-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install bitcoinglobal-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your bitcoinglobalqt binary to `/usr/bin`
and the `../../share/pixmaps/bitcoin128.png` to `/usr/share/pixmaps`

bitcoinglobal-qt.protocol (KDE)

