# Paper Wallet Import Instructions

<p align="center">
    <img src="https://media.discordapp.net/attachments/516295832904138762/542275592704491521/bitcoin.png"
        height="130">
</p>

### Before you begin, you’ll need to download the `bitcoinglobal QT wallet` : https://bitcoinglobalproject.org/wallets/


## Windows/Mac/Linux 

1. Unlock your Wallet. From the menu bar, click on `Settings` then fully Unlock the wallet (uncheck the `for staking only` box).

2. Click on the `Tools` button from the menu bar.  

3. Select `Debug window` .

4. Click on the `Console` tab. 

5. Type:  **importprivkey PrivateKeyHere "label"**  and press Enter.(BE SURE TO INCLUDE THE **""**)  
	>Label is the name you want for your address (For example: **"exchange"**)
	
6. In same menu, click on `Wallet Repair` tab.

7. Click on `Rescan blockchain files`.

*The wallet will restart and rescan the blockchain (it takes a few seconds)*


If you experience any difficulties, please contact one of our experienced bitcoinglobal community members, available on these platforms: 


Discord: https://discord.gg/B8F7Jdv 
(please join the `#help-support` channel for assistance) 
 
Telegram: https://t.me/bitcoinglobalcoin bitcoinglobal
