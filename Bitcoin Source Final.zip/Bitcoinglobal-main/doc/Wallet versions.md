# 2.0.0

-First wallet supporting the forked chain (02-22-2019 Fork)

# 2.0.1

-Initialize nTime to zero (Exchange wallet only)

# 2.0.2

-Improve QT version to  5.9.7

-Fix withdraw issue (input already used, fix from 2.0.1)

-Fix building

# 2.0.3 **WIP**

-Add CMC\bitcoinglobal to Links menu

-Use new fake stake patch from PIVX

-MSW Updates (fix a bug in the RPC causing new addresses to be made when attempting to rename a newly made address)

-Update staking icons

-Hide Orphan Stakes Option

-Add Checkpoints

-POW fixes for testnet
